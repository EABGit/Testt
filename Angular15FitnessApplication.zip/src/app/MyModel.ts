export class MyModel {

    deliveryVersion: string = '';
    environment: string = '';
    testcaseNumber: string = '';
    tableName: string = '';
    selectedBrandName: string = '';
    selectedBrandId: string = '';
    //selectedBrand: string[] = [];
    selectedMicroservice: string = '';
    selectedModelNames: string[] = [];
    selectedWebsites: string[] = [];
    //Selectedlanguages
    Selectedlanguages: string[] = [];
    selectedifu: string='';
    sourceType: string = '';
  }